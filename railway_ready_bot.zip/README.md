# Railway Deploy (Telegram Bot + Telethon Userbot)

## 1) Set Variables in Railway
Required:
- BOT_TOKEN = your BotFather token

Recommended:
- DB_FILE = /data/userbot_data.db   (use Railway Volume for persistence)
Optional:
- LOG_LEVEL = WARNING
- SCREENSHOT_MATCH_WINDOW_SEC = 7200  (2 hours)

## 2) Add a Volume (recommended)
Railway -> Service -> Volumes -> Add Volume
Mount Path: /data

This keeps your DB/session safe across restarts.

## 3) Deploy
Upload this repo or connect GitHub. Railway will detect `requirements.txt` and run:
`python app.py`

## 4) First-time login
Open your bot in Telegram and send `/start` (admin-only). Follow login wizard.

Notes:
- Polling works on Railway, no webhook needed.
- If Telegram has a transient outage (502), the script auto-retries.
