import os
import json
import re
import time
import uuid
import shutil
import sqlite3
import asyncio
import logging
from io import BytesIO, TextIOWrapper
from datetime import datetime, timedelta, date, timezone
from html import escape as html_escape

import qrcode
from telethon import TelegramClient, events
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError

from telegram import Update
from telegram.constants import ParseMode
from telegram.error import BadRequest, NetworkError, TimedOut, RetryAfter
from telegram.ext import (
    Application, CommandHandler, ContextTypes,
    ConversationHandler, MessageHandler, filters
)

from openpyxl import Workbook
from openpyxl.utils import get_column_letter
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

# =========================
# USER CONFIG
# =========================
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")

# Quiet noisy network tracebacks (Termux/mobile networks often trigger 502/Bad Gateway)
LOG_LEVEL = os.environ.get("LOG_LEVEL", "WARNING").upper()
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.WARNING))
for _name in ("telegram", "telegram.ext", "httpx"):
    logging.getLogger(_name).setLevel(logging.ERROR)


UPI_VPA = "chhimanshu67@ptyes"
PAYEE_NAME = "HIMANSHU"

HEADING = "TERMINATOR OTT STORE"

# IST fixed timezone (no tzdata needed)
TZ = timezone(timedelta(hours=5, minutes=30))

# ================= TIME HELPERS =================
def now_ts() -> int:
    return int(time.time())

def today_date():
    # returns datetime.date in TZ
    return datetime.now(TZ).date()

def day_name(d) -> str:
    # accepts datetime.date or datetime/datetime-like
    try:
        if hasattr(d, "strftime"):
            return d.strftime("%a")
    except Exception:
        pass
    return "-"

def date_range_to_ts(d1, d2):
    """Convert two dates (inclusive) to unix timestamps [start, end)."""
    if d1 is None or d2 is None:
        return None, None
    # ensure order
    if d2 < d1:
        d1, d2 = d2, d1
    start_dt = datetime.combine(d1, datetime.min.time(), tzinfo=TZ)
    # end is next day midnight (exclusive)
    end_dt = datetime.combine(d2 + timedelta(days=1), datetime.min.time(), tzinfo=TZ)
    return int(start_dt.timestamp()), int(end_dt.timestamp())

def ts_to_str(ts: int | None) -> str:
    try:
        if not ts:
            return "-"
        dt = datetime.fromtimestamp(int(ts), TZ)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return "-"


def _to_int(v):
    try:
        if v is None:
            return None
        if isinstance(v, int):
            return v
        if isinstance(v, float):
            return int(v)
        s = str(v).strip()
        if not s or s == "-":
            return None
        return int(float(s))
    except Exception:
        return None

def date_day_from_created(created_at) -> tuple[str, str]:
    ts = _to_int(created_at)
    if not ts:
        return "-", "-"
    try:
        dt = datetime.fromtimestamp(ts, TZ)
        return dt.strftime("%Y-%m-%d"), dt.strftime("%a")
    except Exception:
        return "-", "-"

def only_time(ts: int | None) -> str:
    try:
        if not ts:
            return "-"
        dt = datetime.fromtimestamp(int(ts), TZ)
        return dt.strftime("%H:%M")
    except Exception:
        return "-"


KEYWORD_COOLDOWN_SEC = 60

# Duplicate pending protection
DUP_PENDING_WINDOW_SEC = 300
DUP_PENDING_MAX = 3

# Screenshot detection: only accept payment proof for the most recent billed customer (recent pending order)
SCREENSHOT_MATCH_WINDOW_SEC = int(os.environ.get("SCREENSHOT_MATCH_WINDOW_SEC", "7200"))  # default 2 hours

# Backup settings
BACKUP_FOLDER = "Terminator ott"
DB_FILE = os.environ.get("DB_FILE", "/data/userbot_data.db" if os.environ.get("RAILWAY_ENVIRONMENT") else "/storage/emulated/0/userbot_data.db")

# ================= DATABASE HELPERS =================
_db_lock = asyncio.Lock()

def _connect():
    """Create a SQLite connection (thread-safe usage guarded by _db_lock)."""
    # Ensure parent folder exists (useful if DB_FILE is an absolute path)
    try:
        db_dir = os.path.dirname(DB_FILE)
        if db_dir and (not os.path.exists(db_dir)):
            os.makedirs(db_dir, exist_ok=True)
    except Exception:
        pass
    con = sqlite3.connect(DB_FILE, check_same_thread=False)
    try:
        con.execute('PRAGMA journal_mode=WAL;')
        con.execute('PRAGMA synchronous=NORMAL;')
        con.execute('PRAGMA foreign_keys=ON;')
    except Exception:
        pass
    return con

BACKUP_TIME_HOUR = 2  # 2 AM

# =========================
# ADMIN SETUP
# =========================
ADMIN_IDS = {8377499959}  # <-- your Telegram user id(s)



def is_admin(user_id: int) -> bool:
    try:
        return int(user_id) in ADMIN_IDS
    except Exception:
        return False

async def log_admin(app, text: str):
    """Send a message to all configured admins (best-effort).

    We try HTML parse_mode (so <b>, <code>, links, and premium-emoji entities work when present).
    If Telegram rejects entities ("Can't parse entities"), we fall back to plain text.
    """
    for admin_id in ADMIN_IDS:
        try:
            await app.bot.send_message(admin_id, text, parse_mode=ParseMode.HTML)
        except BadRequest:
            # Fallback: strip HTML tags to avoid crashing logs.
            plain = re.sub(r"<[^>]+>", "", text)
            try:
                await app.bot.send_message(admin_id, plain)
            except Exception:
                pass
        except Exception:
            pass

async def db_init():
    async with _db_lock:
        con = _connect()
        cur = con.cursor()

        # ---- settings table ----
        cur.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
        """)

        # ---- keywords table (create first; migrate if old column name is 'word') ----
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='keywords'")
        has_keywords = cur.fetchone() is not None

        if has_keywords:
            cur.execute("PRAGMA table_info(keywords)")
            kw_cols = {row[1] for row in cur.fetchall()}
            # Old versions used: keywords(word TEXT PRIMARY KEY, reply TEXT)
            if "keyword" not in kw_cols:
                legacy_kw = f"keywords_legacy_{int(time.time())}"
                try:
                    cur.execute(f"ALTER TABLE keywords RENAME TO {legacy_kw}")
                except Exception:
                    cur.execute("DROP TABLE IF EXISTS keywords")
                    legacy_kw = None

                cur.execute("""
                CREATE TABLE IF NOT EXISTS keywords (
                    keyword TEXT PRIMARY KEY,
                    reply TEXT NOT NULL,
                    entities_json TEXT
                )
                """)

                if legacy_kw:
                    try:
                        cur.execute(f"PRAGMA table_info({legacy_kw})")
                        legacy_cols = {row[1] for row in cur.fetchall()}

                        if "word" in legacy_cols:
                            cur.execute(f"""
                                INSERT OR IGNORE INTO keywords(keyword, reply)
                                SELECT LOWER(word), reply FROM {legacy_kw}
                            """)
                        elif "keyword" in legacy_cols:
                            cur.execute(f"""
                                INSERT OR IGNORE INTO keywords(keyword, reply)
                                SELECT LOWER(keyword), reply FROM {legacy_kw}
                            """)
                    except Exception:
                        pass

                    try:
                        cur.execute(f"DROP TABLE IF EXISTS {legacy_kw}")
                    except Exception:
                        pass

                con.commit()
        else:
            cur.execute("""
            CREATE TABLE IF NOT EXISTS keywords (
                    keyword TEXT PRIMARY KEY,
                    reply TEXT NOT NULL,
                    entities_json TEXT
                )
            """)
            con.commit()

        
        # Ensure keywords.entities_json exists (for Premium emojis / rich formatting)
        try:
            cur.execute("PRAGMA table_info(keywords)")
            kw_cols2 = {row[1] for row in cur.fetchall()}
            if "entities_json" not in kw_cols2:
                cur.execute("ALTER TABLE keywords ADD COLUMN entities_json TEXT")
                con.commit()
        except Exception:
            pass

# ---- cooldowns table ----
        cur.execute("""
        CREATE TABLE IF NOT EXISTS cooldowns (
            user_id INTEGER NOT NULL,
            keyword TEXT NOT NULL,
            last_ts INTEGER NOT NULL,
            PRIMARY KEY (user_id, keyword)
        )
        """)

        # ---- orders table (auto rebuild if old schema doesn't have order_id) ----
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='orders'")
        has_orders = cur.fetchone() is not None
        if has_orders:
            cur.execute("PRAGMA table_info(orders)")
            order_cols = [row[1] for row in cur.fetchall()]
        else:
            order_cols = []

        if has_orders and ("order_id" not in order_cols):
            legacy_orders = f"orders_legacy_{int(time.time())}"
            try:
                cur.execute(f"ALTER TABLE orders RENAME TO {legacy_orders}")
            except Exception:
                cur.execute("DROP TABLE IF EXISTS orders")
                legacy_orders = None

            cur.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                order_id TEXT PRIMARY KEY,
                customer_chat_id INTEGER,
                customer_chat_title TEXT,
                operator_user_id INTEGER NOT NULL DEFAULT 0,
                operator_username TEXT,
                amount INTEGER NOT NULL DEFAULT 0,
                reason TEXT,
                upi_vpa TEXT,
                status TEXT NOT NULL DEFAULT 'PENDING',
                created_at INTEGER NOT NULL DEFAULT 0,
                updated_at INTEGER NOT NULL DEFAULT 0,
                paid_at INTEGER,
                delivered_at INTEGER,
                notes TEXT
            )
            """)

            # Attempt to migrate minimal legacy data (oid, amount, reason)
            if legacy_orders:
                try:
                    cur.execute(f"PRAGMA table_info({legacy_orders})")
                    legacy_cols = {row[1] for row in cur.fetchall()}
                    if "oid" in legacy_cols:
                        cur.execute(f"""
                            INSERT OR IGNORE INTO orders(order_id, amount, reason, upi_vpa, status, created_at, updated_at)
                            SELECT UPPER(oid),
                                   COALESCE(amount, 0),
                                   reason,
                                   ?,
                                   'PENDING',
                                   0,
                                   0
                            FROM {legacy_orders}
                        """, (UPI_VPA,))
                except Exception:
                    pass

                try:
                    cur.execute(f"DROP TABLE IF EXISTS {legacy_orders}")
                except Exception:
                    pass

            con.commit()

        if not has_orders:
            cur.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                order_id TEXT PRIMARY KEY,
                customer_chat_id INTEGER,
                customer_chat_title TEXT,
                operator_user_id INTEGER NOT NULL DEFAULT 0,
                operator_username TEXT,
                amount INTEGER NOT NULL DEFAULT 0,
                reason TEXT,
                upi_vpa TEXT,
                status TEXT NOT NULL DEFAULT 'PENDING',
                created_at INTEGER NOT NULL DEFAULT 0,
                updated_at INTEGER NOT NULL DEFAULT 0,
                paid_at INTEGER,
                delivered_at INTEGER,
                notes TEXT
            )
            """)
            con.commit()

        # Ensure any missing columns for mid versions
        cur.execute("PRAGMA table_info(orders)")
        existing_cols = {row[1] for row in cur.fetchall()}

        def add_col(name: str, ddl: str):
            if name not in existing_cols:
                cur.execute(ddl)

        add_col("status", "ALTER TABLE orders ADD COLUMN status TEXT NOT NULL DEFAULT 'PENDING'")
        add_col("created_at", "ALTER TABLE orders ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0")
        add_col("updated_at", "ALTER TABLE orders ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0")
        add_col("paid_at", "ALTER TABLE orders ADD COLUMN paid_at INTEGER")
        add_col("delivered_at", "ALTER TABLE orders ADD COLUMN delivered_at INTEGER")
        add_col("notes", "ALTER TABLE orders ADD COLUMN notes TEXT")
        add_col("upi_vpa", "ALTER TABLE orders ADD COLUMN upi_vpa TEXT")
        add_col("customer_chat_id", "ALTER TABLE orders ADD COLUMN customer_chat_id INTEGER")
        add_col("customer_chat_title", "ALTER TABLE orders ADD COLUMN customer_chat_title TEXT")
        add_col("operator_username", "ALTER TABLE orders ADD COLUMN operator_username TEXT")
        add_col("reason", "ALTER TABLE orders ADD COLUMN reason TEXT")
        add_col("operator_user_id", "ALTER TABLE orders ADD COLUMN operator_user_id INTEGER NOT NULL DEFAULT 0")

        # Fix typo column if exists
        if "operation_user_id" in existing_cols:
            try:
                cur.execute("""
                    UPDATE orders
                    SET operator_user_id = operation_user_id
                    WHERE operator_user_id = 0
                """)
            except Exception:
                pass

        cur.execute("CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_orders_operator ON orders(operator_user_id)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)")

        con.commit()
        con.close()

# =========================
# SETTINGS + KEYWORDS HELPERS
# =========================
async def setting_get(key: str) -> str | None:
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("SELECT value FROM settings WHERE key=? LIMIT 1", (key,))
        row = cur.fetchone()
        con.close()
        return row[0] if row else None

async def setting_set(key: str, value: str):
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value)
        )
        con.commit()
        con.close()

async def keyword_list() -> list[tuple[str, str]]:
    """Text-only keyword list (backwards compatible)."""
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("SELECT keyword, reply FROM keywords ORDER BY keyword ASC")
        rows = cur.fetchall()
        con.close()
        return rows


async def keyword_list_rich() -> list[tuple[str, str, str | None]]:
    """Keyword list including stored entities_json (for Premium emoji/rich formatting)."""
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("SELECT keyword, reply, entities_json FROM keywords ORDER BY keyword ASC")
        rows = cur.fetchall()
        con.close()
        return rows


async def keyword_add(keyword: str):
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("INSERT OR IGNORE INTO keywords(keyword, reply) VALUES(?,?)", (keyword, ""))
        con.commit()
        con.close()

async def keyword_set_reply(keyword: str, reply: str, entities_json: str | None = None) -> bool:
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute(
            "UPDATE keywords SET reply=?, entities_json=? WHERE keyword=?",
            (reply, entities_json, keyword)
        )
        changed = cur.rowcount > 0
        con.commit()
        con.close()
        return changed


async def keyword_del(keyword: str) -> bool:
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("DELETE FROM keywords WHERE keyword=?", (keyword,))
        changed = cur.rowcount > 0
        con.commit()
        con.close()
        return changed

async def cooldown_ok(user_id: int, keyword: str) -> bool:
    t = now_ts()
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("SELECT last_ts FROM cooldowns WHERE user_id=? AND keyword=? LIMIT 1", (user_id, keyword))
        row = cur.fetchone()
        if row and (t - int(row[0])) < KEYWORD_COOLDOWN_SEC:
            con.close()
            return False

        cur.execute("""
            INSERT INTO cooldowns(user_id, keyword, last_ts)
            VALUES(?,?,?)
            ON CONFLICT(user_id, keyword) DO UPDATE SET last_ts=excluded.last_ts
        """, (user_id, keyword, t))
        con.commit()
        con.close()
        return True

# =========================
# ORDERS HELPERS
# =========================
async def create_order(operator_user_id: int, operator_username: str, amount: int, reason: str,
                       customer_chat_id: int | None, customer_chat_title: str | None) -> str:
    oid = str(uuid.uuid4()).split("-")[0].upper()
    t = now_ts()
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("""
            INSERT INTO orders(
                order_id, customer_chat_id, customer_chat_title,
                operator_user_id, operator_username,
                amount, reason, upi_vpa,
                status, created_at, updated_at
            )
            VALUES(?,?,?,?,?,?,?,?, 'PENDING', ?,?)
        """, (
            oid, customer_chat_id, customer_chat_title,
            operator_user_id, operator_username,
            amount, reason, UPI_VPA,
            t, t
        ))
        con.commit()
        con.close()
    return oid

async def set_status(order_id: str, status: str, notes: str = "") -> bool:
    t = now_ts()
    async with _db_lock:
        con = _connect()
        cur = con.cursor()

        if status == "PAID":
            cur.execute("""
                UPDATE orders SET status=?, updated_at=?, paid_at=COALESCE(paid_at, ?),
                notes=CASE WHEN ?='' THEN notes ELSE ? END
                WHERE order_id=?
            """, (status, t, t, notes, notes, order_id))
        elif status == "DELIVERED":
            cur.execute("""
                UPDATE orders SET status=?, updated_at=?, delivered_at=COALESCE(delivered_at, ?),
                notes=CASE WHEN ?='' THEN notes ELSE ? END
                WHERE order_id=?
            """, (status, t, t, notes, notes, order_id))
        else:
            cur.execute("""
                UPDATE orders SET status=?, updated_at=?,
                notes=CASE WHEN ?='' THEN notes ELSE ? END
                WHERE order_id=?
            """, (status, t, notes, notes, order_id))

        changed = cur.rowcount > 0
        con.commit()
        con.close()
        return changed

async def force_set_status(order_id: str, status: str, notes: str = "") -> bool:
    # Admin override: clears timestamps when moving back to PENDING/CANCELED
    t = now_ts()
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        status_u = (status or "").upper()
        if status_u in ("PENDING", "CANCELED", "CANCELLED"):
            cur.execute("""
                UPDATE orders SET status=?, updated_at=?, paid_at=NULL, delivered_at=NULL,
                notes=CASE WHEN ?='' THEN notes ELSE ? END
                WHERE order_id=?
            """, ("CANCELED" if status_u=="CANCELLED" else status_u, t, notes, notes, order_id))
        elif status_u == "PAID":
            cur.execute("""
                UPDATE orders SET status=?, updated_at=?, paid_at=COALESCE(paid_at, ?),
                notes=CASE WHEN ?='' THEN notes ELSE ? END
                WHERE order_id=?
            """, (status_u, t, t, notes, notes, order_id))
        elif status_u == "DELIVERED":
            cur.execute("""
                UPDATE orders SET status=?, updated_at=?, delivered_at=COALESCE(delivered_at, ?),
                notes=CASE WHEN ?='' THEN notes ELSE ? END
                WHERE order_id=?
            """, (status_u, t, t, notes, notes, order_id))
        else:
            cur.execute("""
                UPDATE orders SET status=?, updated_at=?,
                notes=CASE WHEN ?='' THEN notes ELSE ? END
                WHERE order_id=?
            """, (status_u, t, notes, notes, order_id))
        changed = cur.rowcount > 0
        con.commit()
        con.close()
        return changed

async def append_note(order_id: str, note: str) -> bool:
    note = (note or "").strip()
    if not note:
        return False
    stamp = datetime.now(TZ).strftime("%d-%m-%Y %I:%M %p")
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("SELECT notes FROM orders WHERE order_id=?", (order_id,))
        row = cur.fetchone()
        if not row:
            con.close()
            return False
        existing = row[0] or ""
        new_notes = (existing + "\n" if existing else "") + f"[{stamp}] {note}"
        cur.execute("UPDATE orders SET notes=?, updated_at=? WHERE order_id=?", (new_notes, now_ts(), order_id))
        ok = cur.rowcount > 0
        con.commit()
        con.close()
        return ok

async def get_order(order_id: str):
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("""
            SELECT order_id, customer_chat_id, customer_chat_title,
                   operator_user_id, operator_username,
                   amount, reason, upi_vpa, status,
                   created_at, updated_at, paid_at, delivered_at, notes
            FROM orders WHERE order_id=?
        """, (order_id,))
        row = cur.fetchone()
        con.close()
        return row

async def list_pending(limit: int = 20):
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("""
            SELECT order_id, customer_chat_title, customer_chat_id, amount, reason, created_at
            FROM orders WHERE status='PENDING'
            ORDER BY created_at DESC LIMIT ?
        """, (limit,))
        rows = cur.fetchall()
        con.close()
        return rows


async def latest_pending_for_customer(customer_chat_id: int):
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute(
            "SELECT order_id, amount, reason, created_at FROM orders "
            "WHERE status='PENDING' AND customer_chat_id=? "
            "ORDER BY created_at DESC LIMIT 1",
            (customer_chat_id,)
        )
        row = cur.fetchone()
        con.close()
        return row


async def pending_order_for_customer_recent(customer_chat_id: int, order_id: str | None = None):
    """Return (order_id, amount, reason, created_at) for a customer's PENDING order.
    If order_id is provided, it must match and belong to that customer.
    Only returns an order if it was created within SCREENSHOT_MATCH_WINDOW_SEC.
    """
    cutoff = now_ts() - SCREENSHOT_MATCH_WINDOW_SEC
    async with _db_lock:
        con = _connect(); cur = con.cursor()
        if order_id:
            cur.execute(
                "SELECT order_id, amount, reason, created_at FROM orders "
                "WHERE status='PENDING' AND customer_chat_id=? AND UPPER(order_id)=? LIMIT 1",
                (customer_chat_id, order_id.upper())
            )
            row = cur.fetchone()
        else:
            cur.execute(
                "SELECT order_id, amount, reason, created_at FROM orders "
                "WHERE status='PENDING' AND customer_chat_id=? "
                "ORDER BY created_at DESC LIMIT 1",
                (customer_chat_id,)
            )
            row = cur.fetchone()
        con.close()
    if not row:
        return None
    try:
        created_at = int(row[3] or 0)
    except Exception:
        created_at = 0
    if created_at and created_at >= cutoff:
        return row
    return None

def _effective_collect_ts(row) -> int:
    # row layout from list_collected_filtered():
    # (order_id, operator_username, operator_user_id, customer_chat_title, customer_chat_id,
    #  amount, reason, status, paid_at, delivered_at, created_at)
    paid_at = row[8]
    delivered_at = row[9]
    created_at = row[10]
    return int(paid_at or delivered_at or created_at)

async def list_collected_filtered(start_ts: int | None, end_ts: int | None, limit: int = 50):
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("""
            SELECT order_id, operator_username, operator_user_id, customer_chat_title, customer_chat_id, amount, reason, status, paid_at, delivered_at, created_at
            FROM orders
            WHERE status IN ('PAID','DELIVERED')
            ORDER BY COALESCE(paid_at, delivered_at, created_at) DESC
        """)
        rows = cur.fetchall()
        con.close()

    if start_ts is None or end_ts is None:
        return rows[:limit]

    filtered = []
    for r in rows:
        ts = _effective_collect_ts(r)
        if start_ts <= ts <= end_ts:
            filtered.append(r)
        if len(filtered) >= limit:
            break
    return filtered

async def total_collected_filtered(start_ts: int | None, end_ts: int | None) -> int:
    rows = await list_collected_filtered(start_ts, end_ts, limit=10_000_000)
    return sum(int(r[5]) for r in rows)

async def find_orders(query: str, limit: int = 30):
    """Find orders by order id, customer username/name, or reason text."""
    q = (query or "").strip()
    if not q:
        return []
    async with _db_lock:
        con = _connect()
        cur = con.cursor()

        # 1) Exact Order ID like ABC123
        if re.fullmatch(r"[A-Z0-9]{6,}", q.upper()):
            cur.execute("""
                SELECT order_id, customer_chat_title, customer_chat_id,
                       amount, reason, status, created_at
                FROM orders
                WHERE order_id=?
                LIMIT 1
            """, (q.upper(),))
            rows = cur.fetchall()

        # 2) Customer username (stored like @username in customer_chat_title)
        elif q.startswith("@"):
            uname = q.lower()
            cur.execute("""
                SELECT order_id, customer_chat_title, customer_chat_id,
                       amount, reason, status, created_at
                FROM orders
                WHERE LOWER(customer_chat_title)=?
                ORDER BY created_at DESC
                LIMIT ?
            """, (uname, limit))
            rows = cur.fetchall()

        # 3) Fallback: search in reason OR customer title
        else:
            like = f"%{q.lower()}%"
            cur.execute("""
                SELECT order_id, customer_chat_title, customer_chat_id,
                       amount, reason, status, created_at
                FROM orders
                WHERE LOWER(reason) LIKE ? OR LOWER(customer_chat_title) LIKE ?
                ORDER BY created_at DESC
                LIMIT ?
            """, (like, like, limit))
            rows = cur.fetchall()

        con.close()
        return rows

async def count_recent_pending(operator_user_id: int, window_sec: int) -> int:
    cutoff = now_ts() - window_sec
    async with _db_lock:
        con = _connect()
        cur = con.cursor()
        cur.execute("""
            SELECT COUNT(*) FROM orders
            WHERE operator_user_id=? AND status='PENDING' AND created_at>=?
        """, (operator_user_id, cutoff))
        n = int(cur.fetchone()[0])
        con.close()
        return n

# =========================
# QR
# =========================
def build_upi_uri(amount: int, note: str = "") -> str:
    note = re.sub(r"\s+", " ", (note or "").strip())[:70]
    if note:
        return f"upi://pay?pa={UPI_VPA}&pn={PAYEE_NAME}&am={amount}&cu=INR&tn={note}"
    return f"upi://pay?pa={UPI_VPA}&pn={PAYEE_NAME}&am={amount}&cu=INR"

def make_qr_png_bytes(upi_uri: str) -> BytesIO:
    img = qrcode.make(upi_uri)
    bio = BytesIO()
    bio.name = "upi_qr.png"
    img.save(bio, format="PNG")
    bio.seek(0)
    return bio

# =========================
# EXPORTS
# =========================
def export_xlsx_bytes(rows, title_date: str, title_day: str, total: int) -> BytesIO:
    wb = Workbook()
    ws = wb.active
    ws.title = "Collection"

    ws.merge_cells("A1:H1")
    ws["A1"] = HEADING
    ws["A2"] = f"Date: {title_date}"
    ws["A3"] = f"Day : {title_day}"
    ws["A5"] = f"Total Collection (PAID+DELIVERED): ₹{total}"

    headers = ["Order ID", "Customer", "Amount", "Reason", "Status", "Created", "Paid At", "Delivered At"]
    ws.append([])
    ws.append(headers)

    for r in rows:
        oid, op_uname, op_uid, cust_title, cust_id, amt, reason, status, paid_at, delivered_at, created_at = r
        ws.append([
            oid,
            cust_title or "",
            int(amt),
            reason or "",
            status,
            ts_to_str(created_at),
            ts_to_str(paid_at),
            ts_to_str(delivered_at)
        ])

    ws.append([])
    ws.append(["TOTAL", "", total, "", "", "", "", ""])

    for col in range(1, len(headers) + 1):
        ws.column_dimensions[get_column_letter(col)].width = 18

    bio = BytesIO()
    bio.name = "collection.xlsx"
    wb.save(bio)
    bio.seek(0)
    return bio


import csv

def export_csv_bytes(rows, title_date: str, title_day: str, total: int) -> BytesIO:
    bio = BytesIO()
    bio.name = "collection.csv"

    # csv.writer writes TEXT, so wrap BytesIO with TextIOWrapper
    text = TextIOWrapper(bio, encoding="utf-8-sig", newline="")  # utf-8-sig helps Excel
    writer = csv.writer(text, lineterminator="\n")

    writer.writerow([HEADING])
    writer.writerow([f"Date: {title_date}"])
    writer.writerow([f"Day : {title_day}"])
    writer.writerow([f"Total Collection (PAID+DELIVERED): {total}"])
    writer.writerow([])

    headers = ["Order ID","Date","Day","Customer","Amount","Reason","Status","Created At","Paid At","Delivered At"]
    writer.writerow(headers)

    for r in rows:
        if len(r) == 9:
            oid, customer_name, customer_chat_id, amt, reason, status, paid_at, delivered_at, created_at = r
            op_uname, op_uid = "", ""
            cust_title = customer_name
            cust_id = customer_chat_id
        else:
            oid, op_uname, op_uid, cust_title, cust_id, amt, reason, status, paid_at, delivered_at, created_at = r

        d_str, day_str = date_day_from_created(created_at)
        writer.writerow([oid, d_str, day_str, (cust_title or ""),
            int(_to_int(amt) or 0),
            (reason or ""), (status or ""),
            ts_to_str(created_at), ts_to_str(paid_at), ts_to_str(delivered_at),
        ])

    text.flush()
    # Detach wrapper so it won't close the underlying BytesIO (fixes 'I/O operation on closed file')
    try:
        text.detach()
    except Exception:
        pass
    bio.seek(0)
    return bio


def export_pdf_bytes(rows, title_date: str, title_day: str, total: int) -> BytesIO:
    """PDF export.
    Includes Date+Day columns (from created_at) and shows Order ID in the table.
    Uses a Unicode font (₹) if DejaVuSans.ttf is present.
    """
    bio = BytesIO()
    bio.name = "collection.pdf"

    # Try to use a Unicode font so ₹ and names render correctly
    font_name = "Helvetica"
    try:
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        if os.path.exists("DejaVuSans.ttf"):
            pdfmetrics.registerFont(TTFont("DejaVu", "DejaVuSans.ttf"))
            font_name = "DejaVu"
    except Exception:
        font_name = "Helvetica"

    def money(n: int) -> str:
        # If Unicode font not available, avoid ₹ to prevent boxes
        return f"₹{n}" if font_name != "Helvetica" else f"INR {n}"

    def _to_int(v):
        try:
            if v is None:
                return None
            if isinstance(v, int):
                return v
            if isinstance(v, float):
                return int(v)
            s = str(v).strip()
            if not s or s == "-":
                return None
            return int(float(s))
        except Exception:
            return None

    def date_day_from_created(created_at) -> tuple[str, str]:
        ts = _to_int(created_at)
        if not ts:
            return "-", "-"
        try:
            dt = datetime.fromtimestamp(ts, TZ)
            return dt.strftime("%Y-%m-%d"), dt.strftime("%a")
        except Exception:
            return "-", "-"

    c = canvas.Canvas(bio, pagesize=A4)
    width, height = A4
    y = height - 60

    c.setFont(font_name, 16)
    c.drawCentredString(width / 2, y, HEADING)
    y -= 30

    c.setFont(font_name, 11)
    c.drawString(40, y, f"Date: {title_date}")
    y -= 15
    c.drawString(40, y, f"Day : {title_day}")
    y -= 20

    c.setFont(font_name, 12)
    c.drawString(40, y, f"Total Collection (PAID+DELIVERED): {money(total)}")
    y -= 22

    # Column positions (A4 width ~595)
    X_OID = 40
    X_DATE = 110
    X_DAY = 170
    X_CUST = 220
    X_AMT = 380
    X_STATUS = 445
    X_REASON = 505

    def draw_header():
        nonlocal y
        c.setFont(font_name, 8.8)
        c.drawString(X_OID, y, "Order ID")
        c.drawString(X_DATE, y, "Date")
        c.drawString(X_DAY, y, "Day")
        c.drawString(X_CUST, y, "Customer")
        c.drawString(X_AMT, y, "Amount")
        c.drawString(X_STATUS, y, "Status")
        c.drawString(X_REASON, y, "Reason")
        y -= 12
        c.setFont(font_name, 8.2)

    draw_header()

    for r in rows:
        # Supported row formats:
        # v2/v3: (order_id, customer_name, customer_chat_id, amount, reason, status, paid_at, delivered_at, created_at)
        # v4   : (order_id, operator_username, operator_user_id, customer_chat_title, customer_chat_id, amount, reason, status, paid_at, delivered_at, created_at)
        if len(r) == 9:
            oid, customer_name, customer_chat_id, amt, reason, status, paid_at, delivered_at, created_at = r
        elif len(r) == 11:
            oid, operator_username, operator_user_id, customer_chat_title, customer_chat_id, amt, reason, status, paid_at, delivered_at, created_at = r
            customer_name = customer_chat_title
        else:
            # Unknown format - try best-effort
            oid = r[0] if len(r) > 0 else ""
            customer_name = r[3] if len(r) > 3 else ""
            customer_chat_id = r[4] if len(r) > 4 else ""
            amt = r[5] if len(r) > 5 else 0
            reason = r[6] if len(r) > 6 else ""
            status = r[7] if len(r) > 7 else ""
            created_at = r[10] if len(r) > 10 else None

        if y < 60:
            c.showPage()
            y = height - 60
            draw_header()

        created_date, created_day = date_day_from_created(created_at)

        oid_short = (str(oid) if oid is not None else "-")[:10]
        customer = (customer_name or str(customer_chat_id) or "-")[:20]
        reason_short = (reason or "")[:22]

        c.drawString(X_OID, y, oid_short)
        c.drawString(X_DATE, y, created_date)
        c.drawString(X_DAY, y, created_day)
        c.drawString(X_CUST, y, customer)
        c.drawString(X_AMT, y, money(int(_to_int(amt) or 0)))
        c.drawString(X_STATUS, y, (status or "-")[:10])
        c.drawString(X_REASON, y, reason_short)
        y -= 11

    c.showPage()
    c.save()
    bio.seek(0)
    return bio
def parse_collection_args(args: list[str]) -> tuple[str, str, int | None, int | None]:
    if not args:
        d = today_date()
        s, e = date_range_to_ts(d, d)
        return d.strftime("%d-%m-%Y"), day_name(d), s, e

    a0 = args[0].lower()
    if a0 == "total":
        d = today_date()
        return d.strftime("%d-%m-%Y"), day_name(d), None, None

    if a0 == "today":
        d = today_date()
        s, e = date_range_to_ts(d, d)
        return d.strftime("%d-%m-%Y"), day_name(d), s, e

    if a0 == "yesterday":
        d = today_date() - timedelta(days=1)
        s, e = date_range_to_ts(d, d)
        return d.strftime("%d-%m-%Y"), day_name(d), s, e

    if a0 == "week":
        d2 = today_date()
        d1 = d2 - timedelta(days=6)
        s, e = date_range_to_ts(d1, d2)
        title = f"{d1.strftime('%d-%m-%Y')} to {d2.strftime('%d-%m-%Y')}"
        return title, "Range", s, e

    if a0 == "month":
        d2 = today_date()
        d1 = d2.replace(day=1)
        s, e = date_range_to_ts(d1, d2)
        title = f"{d1.strftime('%d-%m-%Y')} to {d2.strftime('%d-%m-%Y')}"
        return title, "Range", s, e

    if len(args) >= 2:
        try:
            d1 = datetime.strptime(args[0], "%d-%m-%Y").date()
            d2 = datetime.strptime(args[1], "%d-%m-%Y").date()
            if d2 < d1:
                d1, d2 = d2, d1
            s, e = date_range_to_ts(d1, d2)
            title = f"{d1.strftime('%d-%m-%Y')} to {d2.strftime('%d-%m-%Y')}"
            day = day_name(d1) if d1 == d2 else "Range"
            return title, day, s, e
        except Exception:
            pass

    d = today_date()
    s, e = date_range_to_ts(d, d)
    return d.strftime("%d-%m-%Y"), day_name(d), s, e

# =========================
# TELETHON USERBOT
# =========================
telethon_client: TelegramClient | None = None

async def start_userbot(app: Application):
    global telethon_client

    sess = await setting_get("telethon_session")
    api_id = await setting_get("api_id")
    api_hash = await setting_get("api_hash")

    if not (sess and api_id and api_hash):
        return

    if telethon_client and telethon_client.is_connected():
        return

    telethon_client = TelegramClient(StringSession(sess), int(api_id), api_hash)
    await telethon_client.connect()

    @telethon_client.on(events.NewMessage(incoming=True))
    async def on_incoming(event):
        if not event.is_private:
            return

        sender = await event.get_sender()
        if not sender or getattr(sender, "bot", False):
            return

        # -------------------------
        # -------------------------
# Screenshot / payment proof detection (customer sends photo)
# Only accept if THIS customer has a recent PENDING order (i.e., you billed them recently).
# -------------------------
try:
    msg = event.message
    has_media = bool(getattr(msg, "media", None))
except Exception:
    msg = None
    has_media = False

caption_text = (event.raw_text or "").strip()

if has_media:
    is_image = False
    try:
        if msg.photo:
            is_image = True
        elif msg.document and getattr(msg.document, "mime_type", ""):
            is_image = msg.document.mime_type.startswith("image/")
    except Exception:
        pass

    if is_image:
        # Try to find order id in caption/text
        hinted_oid = None
        if caption_text:
            mo = re.search(r"\b([A-Z0-9]{6,})\b", caption_text.upper())
            if mo:
                hinted_oid = mo.group(1)

        # Validate that there is a recent pending order for this customer
        recent = await pending_order_for_customer_recent(event.chat_id, hinted_oid)
        if not recent and not hinted_oid:
            # Fallback to latest pending (still must be recent)
            recent = await pending_order_for_customer_recent(event.chat_id, None)

        if not recent:
            # Not a recently billed customer: ignore screenshot (no admin log, no auto-reply)
            return

        found_oid, _amt, _reason, _created_at = recent

        sender = await event.get_sender()
        uname = getattr(sender, "username", None)
        name = " ".join([p for p in [getattr(sender, "first_name", ""), getattr(sender, "last_name", "")] if p]).strip()
        customer_label = f"@{uname}" if uname else (name or str(event.chat_id))

        note = (caption_text[:120] + "…") if len(caption_text) > 120 else caption_text
        order_part = f"<code>{found_oid}</code>"

        await log_admin(
            app,
            "🧾 <b>Payment Screenshot Received</b>\n"
            f"👤 <b>Customer:</b> {customer_label}\n"
            f"🧾 <b>Order:</b> {order_part}\n"
            f"📝 <b>Caption:</b> {note or '-'}"
        )

        # Optional: quick acknowledgment to customer
        try:
            await event.reply(f"✅ Screenshot received for Order {found_oid}. Please wait.")
        except Exception:
            pass
        return

# -------------------------
# Keyword auto-reply (text only)
 (text only)
        # -------------------------
        if not caption_text:
            return

        msg_low = caption_text.lower()
        rules = await keyword_list_rich()
        for kw, reply, entities_json in rules:
            kw_low = (kw or "").lower().strip()
            if not kw_low or not (reply or "").strip():
                continue
            if kw_low in msg_low:
                ok = await cooldown_ok(sender.id, kw_low)
                if not ok:
                    return

                # If we have stored entities (Premium emojis / rich format), try to send with formatting entities.
                if entities_json:
                    try:
                        from telethon.tl import types as tl_types  # type: ignore
                        ents_data = json.loads(entities_json)

                        ents = []
                        for e in ents_data:
                            t = (e.get("type") or "").lower()
                            off = int(e.get("offset", 0))
                            ln = int(e.get("length", 0))

                            if ln <= 0:
                                continue

                            if t == "bold":
                                ents.append(tl_types.MessageEntityBold(off, ln))
                            elif t == "italic":
                                ents.append(tl_types.MessageEntityItalic(off, ln))
                            elif t == "underline":
                                ents.append(tl_types.MessageEntityUnderline(off, ln))
                            elif t == "strikethrough":
                                ents.append(tl_types.MessageEntityStrike(off, ln))
                            elif t == "spoiler":
                                ents.append(tl_types.MessageEntitySpoiler(off, ln))
                            elif t == "code":
                                ents.append(tl_types.MessageEntityCode(off, ln))
                            elif t == "pre":
                                ents.append(tl_types.MessageEntityPre(off, ln, e.get("language") or ""))
                            elif t == "text_link":
                                ents.append(tl_types.MessageEntityTextUrl(off, ln, e.get("url") or ""))
                            elif t == "text_mention":
                                uid = int(e.get("user_id") or 0)
                                if uid:
                                    ents.append(tl_types.MessageEntityMentionName(off, ln, uid))
                            elif t == "custom_emoji":
                                doc_id = int(e.get("custom_emoji_id") or 0)
                                if doc_id:
                                    ents.append(tl_types.MessageEntityCustomEmoji(off, ln, doc_id))

                        if ents:
                            await telethon_client.send_message(
                                event.chat_id,
                                reply,
                                formatting_entities=ents,
                                reply_to=event.message.id
                            )
                            return
                    except Exception:
                        # fallback to plain text below
                        pass

                await event.reply(reply)
                return

    @telethon_client.on(events.NewMessage(outgoing=True))
    async def on_outgoing(event):
        text = (event.raw_text or "").strip()
        if not text:
            return

        m = re.match(r"^/payr\s+(\d+)\s+(.+)$", text, re.IGNORECASE)
        if not m:
            return

        amount = int(m.group(1))
        reason = m.group(2).strip()
        if amount <= 0 or not reason:
            return

        me = await telethon_client.get_me()

        pending_count = await count_recent_pending(me.id, DUP_PENDING_WINDOW_SEC)
        if pending_count >= DUP_PENDING_MAX:
            try:
                await event.reply("⚠️ Too many pending orders recently. Please finish old pending payments first.")
            except Exception:
                pass
            return

        chat = await event.get_chat()
        # Customer display name for exports/cards
        chat_title = getattr(chat, "title", None)
        if not chat_title:
            uname = getattr(chat, "username", None)
            if uname:
                chat_title = f"@{uname}"
            else:
                fn = getattr(chat, "first_name", "") or ""
                ln = getattr(chat, "last_name", "") or ""
                name = (fn + " " + ln).strip()
                chat_title = name if name else str(event.chat_id)

        order_id = await create_order(
            operator_user_id=me.id,
            operator_username=(me.username or ""),
            amount=amount,
            reason=reason,
            customer_chat_id=event.chat_id,
            customer_chat_title=chat_title
        )

        upi_uri = build_upi_uri(amount=amount, note=f"Order:{order_id}")
        qr_png = make_qr_png_bytes(upi_uri)

        msg = (
            "💳 SCAN THE QR AND PAY!\n\n"
            f"🧾 Order ID: {order_id}\n"
            f"💰 Amount: ₹{amount}\n"
            f"📄 Reason of Payment: {reason}\n"
            f"👤 Payee: {PAYEE_NAME}"
        )

        try:
            await event.delete()
        except Exception:
            pass

        try:
            await telethon_client.send_file(
                event.chat_id,
                qr_png,
                caption=msg
            )
        except Exception:
            pass

        await log_admin(app, f"🧾 <b>New PENDING Order</b>\n<code>{order_id}</code> | ₹{amount} | {reason}")

    await log_admin(app, "✅ Userbot connected and running.")

# =========================
# LOGIN WIZARD
# =========================
S_API_ID, S_API_HASH, S_PHONE, S_CODE, S_2FA = range(5)

async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message:
        return
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Not allowed.")
        return

    sess = await setting_get("telethon_session")
    if sess:
        await update.message.reply_text(
            "✅ Already logged in.\n\n"
            "Keyword commands:\n"
            "<code>/addkeyword prime</code>\n"
            "<code>/setreply prime your message</code>\n"
            "<code>/delkeyword prime</code>\n\n"
            "Orders:\n"
            "<code>/pending</code>\n"
            "<code>/paid ORDERID</code>\n"
            "<code>/delivered ORDERID</code>\n"
            "<code>/cancel ORDERID note</code>\n"
            "<code>/order ORDERID</code>\n"
            "<code>/find @username</code> or <code>/find ORDERID</code>\n\n"
            "Collection:\n"
            "<code>/collection today</code>\n"
            "<code>/collection yesterday</code>\n"
            "<code>/collection total</code>\n"
            "<code>/collection DD-MM-YYYY DD-MM-YYYY</code>\n\n"
            "Exports:\n"
            "<code>/exportxlsx total</code>\n"
            "<code>/exportpdf today</code>\n\n"
            "Billing in customer chat (from your Telegram account):\n"
            "<code>/Payr 50 prime 1 month</code>\n",
            parse_mode=ParseMode.HTML
        )
        await start_userbot(context.application)
        return ConversationHandler.END

    await update.message.reply_text("Login setup:\nSend your <b>API ID</b>:", parse_mode=ParseMode.HTML)
    return S_API_ID

async def login_api_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    if not text.isdigit():
        await update.message.reply_text("API ID must be a number. Send again:")
        return S_API_ID
    context.user_data["api_id"] = text
    await update.message.reply_text("Now send your <b>API HASH</b>:", parse_mode=ParseMode.HTML)
    return S_API_HASH

async def login_api_hash(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    if len(text) < 10:
        await update.message.reply_text("API HASH looks wrong. Send again:")
        return S_API_HASH
    context.user_data["api_hash"] = text
    await update.message.reply_text(
        "Now send your <b>Phone number</b> with country code.\nExample: +91XXXXXXXXXX",
        parse_mode=ParseMode.HTML
    )
    return S_PHONE

async def login_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    phone = (update.message.text or "").strip()
    if not phone.startswith("+") or len(phone) < 8:
        await update.message.reply_text("Phone must be like +91XXXXXXXXXX. Send again:")
        return S_PHONE

    api_id = int(context.user_data["api_id"])
    api_hash = context.user_data["api_hash"]

    context.user_data["tmp_client"] = TelegramClient(StringSession(), api_id, api_hash)
    await context.user_data["tmp_client"].connect()

    try:
        sent = await context.user_data["tmp_client"].send_code_request(phone)
        context.user_data["phone"] = phone
        context.user_data["phone_hash"] = sent.phone_code_hash
    except Exception as e:
        await update.message.reply_text(f"Failed to send code: {e}")
        return ConversationHandler.END

    await update.message.reply_text("OTP sent ✅\nNow send the <b>Telegram code</b>:", parse_mode=ParseMode.HTML)
    return S_CODE

async def login_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    code = (update.message.text or "").strip().replace(" ", "")
    if len(code) < 3:
        await update.message.reply_text("Code looks wrong. Send again:")
        return S_CODE

    tmp: TelegramClient = context.user_data["tmp_client"]
    phone = context.user_data["phone"]
    phone_hash = context.user_data["phone_hash"]

    try:
        await tmp.sign_in(phone=phone, code=code, phone_code_hash=phone_hash)
    except SessionPasswordNeededError:
        await update.message.reply_text("2FA enabled ✅\nSend your <b>2FA password</b>:", parse_mode=ParseMode.HTML)
        return S_2FA
    except Exception as e:
        await update.message.reply_text(f"Login failed: {e}\nSend code again:")
        return S_CODE

    sess = tmp.session.save()
    await setting_set("api_id", str(context.user_data["api_id"]))
    await setting_set("api_hash", str(context.user_data["api_hash"]))
    await setting_set("telethon_session", sess)

    await tmp.disconnect()
    await update.message.reply_text("✅ Login success! Session saved.\nUserbot will start now.")
    await start_userbot(context.application)
    return ConversationHandler.END

async def login_2fa(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pwd = (update.message.text or "").strip()
    tmp: TelegramClient = context.user_data["tmp_client"]

    try:
        await tmp.sign_in(password=pwd)
    except Exception as e:
        await update.message.reply_text(f"2FA failed: {e}\nSend password again:")
        return S_2FA

    sess = tmp.session.save()
    await setting_set("api_id", str(context.user_data["api_id"]))
    await setting_set("api_hash", str(context.user_data["api_hash"]))
    await setting_set("telethon_session", sess)

    await tmp.disconnect()
    await update.message.reply_text("✅ Login success! Session saved.\nUserbot will start now.")
    await start_userbot(context.application)
    return ConversationHandler.END

async def cancel_login(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        tmp = context.user_data.get("tmp_client")
        if tmp:
            await tmp.disconnect()
    except Exception:
        pass
    await update.message.reply_text("Login canceled.")
    return ConversationHandler.END

# =========================
# CONTROLLER BOT COMMANDS
# =========================
async def addkeyword_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /addkeyword <keyword>")
        return
    kw = context.args[0].strip().lower()
    await keyword_add(kw)
    await update.message.reply_text(
        f"✅ Added keyword: <code>{kw}</code>\nNow set reply:\n<code>/setreply {kw} your message</code>",
        parse_mode=ParseMode.HTML
    )

async def delkeyword_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /delkeyword <keyword>")
        return
    kw = context.args[0].strip().lower()
    changed = await keyword_del(kw)
    if changed:
        await update.message.reply_text(f"🗑️ Deleted keyword: <code>{kw}</code>", parse_mode=ParseMode.HTML)
    else:
        await update.message.reply_text(f"⚠️ Keyword not found: <code>{kw}</code>", parse_mode=ParseMode.HTML)


async def setreply_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if not update.message:
        return

    raw = update.message.text or ""
    # Supports:
    # 1) /setreply <keyword>\n<your multi-line message...>
    # 2) /setreply <keyword> <your message...>
    mm = re.match(r"^/setreply\s+(\S+)\s+([\s\S]+)$", raw, flags=re.IGNORECASE)
    if not mm:
        await update.message.reply_text("Usage:\n/setreply <keyword>\n<your multi-line message>")
        return

    kw = (mm.group(1) or "").strip().lower()
    reply_text = mm.group(2) or ""
    if not kw or not reply_text.strip():
        await update.message.reply_text("Usage:\n/setreply <keyword>\n<your multi-line message>")
        return

    # ---- Premium emoji / rich format support ----
    # Telegram stores formatting (including Premium custom emojis) as entities.
    # We store the reply text + adjusted entities for just the reply portion.
    entities_json = None
    try:
        ents = list(update.message.entities or [])
        # reply_text starts at this index in the original message
        reply_start = mm.start(2)

        packed = []
        for e in ents:
            # keep only entities that overlap the reply part
            e_start = getattr(e, "offset", 0)
            e_len = getattr(e, "length", 0)
            e_end = e_start + e_len
            if e_end <= reply_start:
                continue
            if e_start >= len(raw):
                continue

            # clip to reply range
            new_off = max(e_start, reply_start) - reply_start
            new_end = min(e_end, len(raw)) - reply_start
            new_len = max(0, new_end - max(e_start, reply_start))

            if new_len <= 0:
                continue

            item = {
                "type": e.type,
                "offset": int(new_off),
                "length": int(new_len),
            }
            # optional fields (depending on entity type)
            if getattr(e, "url", None):
                item["url"] = e.url
            if getattr(e, "language", None):
                item["language"] = e.language
            if getattr(e, "custom_emoji_id", None):
                item["custom_emoji_id"] = e.custom_emoji_id
            if getattr(e, "user", None) and getattr(e.user, "id", None):
                item["user_id"] = int(e.user.id)

            packed.append(item)

        if packed:
            entities_json = json.dumps(packed, ensure_ascii=False)
    except Exception:
        entities_json = None

    ok = await keyword_set_reply(kw, reply_text, entities_json)
    if ok:
        await update.message.reply_text(f"✅ Reply saved for keyword: <code>{kw}</code>", parse_mode=ParseMode.HTML)
    else:
        await update.message.reply_text("❌ Keyword not found. Add it first with /addkeyword <keyword>.", parse_mode=ParseMode.HTML)


async def pending_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    limit = 20
    if context.args:
        try:
            limit = max(1, min(50, int(context.args[0])))
        except Exception:
            pass
    rows = await list_pending(limit)
    if not rows:
        await update.message.reply_text("✅ No pending orders.")
        return
    out = ["⏳ <b>Pending Orders</b>"]
    for oid, cust_title, cust_id, amt, reason, created_at in rows:
        who = cust_title or (str(cust_id) if cust_id is not None else "-")
        out.append(
            f"• <code>{oid}</code> | ₹{int(amt)} | {html_escape((reason or '')[:24])} | "
            f"{html_escape(who)} | {ts_to_str(created_at)}"
        )
    await update.message.reply_text("\n".join(out), parse_mode=ParseMode.HTML)

async def paid_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /paid <orderid>")
        return
    oid = context.args[0].strip().upper()
    ok = await set_status(oid, "PAID")
    if not ok:
        await update.message.reply_text("Order not found.")
        return
    row = await get_order(oid)
    await update.message.reply_text("✅ Marked PAID\n\n" + order_card(row), parse_mode=ParseMode.HTML)
    await log_admin(context.application, f"✅ <b>PAID</b> <code>{oid}</code>")

async def delivered_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /delivered <orderid>")
        return
    oid = context.args[0].strip().upper()
    ok = await set_status(oid, "DELIVERED")
    if not ok:
        await update.message.reply_text("Order not found.")
        return
    row = await get_order(oid)
    await update.message.reply_text("📦 Marked DELIVERED\n\n" + order_card(row), parse_mode=ParseMode.HTML)
    await log_admin(context.application, f"📦 <b>DELIVERED</b> <code>{oid}</code>")

def order_card(row) -> str:
    """Render an order row (from get_order) as safe HTML.
    NOTE: Operator username/user_id is intentionally hidden (admin requested).
    """
    if not row:
        return "-"
    (order_id, customer_chat_id, customer_chat_title,
     operator_user_id, operator_username,
     amount, reason, upi_vpa, status,
     created_at, updated_at, paid_at, delivered_at, notes) = row

    cust = customer_chat_title or str(customer_chat_id or "")
    cust_safe = html_escape(cust)
    reason_safe = html_escape(reason or "-")
    notes_safe = html_escape(notes or "-")

    parts = [
        f"🧾 <b>Order</b>: <code>{html_escape(str(order_id))}</code>",
        f"👤 <b>Customer</b>: {cust_safe}",
        f"💰 <b>Amount</b>: ₹{amount}",
        f"📝 <b>Reason</b>: {reason_safe}",
        f"📌 <b>Status</b>: {html_escape(str(status))}",
        f"🕒 <b>Created</b>: {html_escape(ts_to_str(created_at))}",
        f"🔄 <b>Updated</b>: {html_escape(ts_to_str(updated_at))}",
        f"✅ <b>Paid</b>: {html_escape(ts_to_str(paid_at))}",
        f"📦 <b>Delivered</b>: {html_escape(ts_to_str(delivered_at))}",
        f"🗒️ <b>Notes</b>: {notes_safe}",
    ]
    return "\n".join(parts)

async def cancel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) < 1:
        await update.message.reply_text("Usage: /cancel <orderid> [note...]")
        return
    oid = context.args[0].strip().upper()
    note = " ".join(context.args[1:]).strip() if len(context.args) > 1 else ""
    ok = await set_status(oid, "CANCELED", notes=note)
    if not ok:
        await update.message.reply_text("Order not found.")
        return
    row = await get_order(oid)
    await update.message.reply_text("❌ CANCELED\n\n" + order_card(row), parse_mode=ParseMode.HTML)
    await log_admin(context.application, f"❌ <b>CANCELED</b> <code>{oid}</code>")

async def order_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /order <orderid>")
        return
    oid = context.args[0].strip().upper()
    row = await get_order(oid)
    if not row:
        await update.message.reply_text("Order not found.")
        return
    await update.message.reply_text(order_card(row), parse_mode=ParseMode.HTML)

async def find_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if not context.args:
        await update.message.reply_text("Usage: /find @username OR /find <orderid> OR /find <reason text>")
        return
    q = " ".join(context.args).strip()
    rows = await find_orders(q)
    if not rows:
        await update.message.reply_text("No results.")
        return

    out = [f"🔎 <b>Results for:</b> <code>{html_escape(q)}</code>"]
    for oid, cust_title, cust_id, amt, reason, status, created_at in rows[:30]:
        who = cust_title or "-"
        out.append(
            f"• <code>{oid}</code> | ₹{int(amt)} | {html_escape(status)} | {html_escape((reason or '')[:24])} | "
            f"{html_escape(who)} | {ts_to_str(created_at)}"
        )
    await update.message.reply_text("\n".join(out), parse_mode=ParseMode.HTML)


async def setcustomer_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manually set/override customer username/title for an order.
    Usage: /setcustomer <order_id_or_prefix> @username_or_name
    This updates customer_chat_title and will reflect in /find and all exports.
    """
    if not is_admin(update.effective_user.id):
        return

    if len(context.args) < 2:
        await update.message.reply_text("Usage: /setcustomer <order_id_or_prefix> @username_or_name")
        return

    raw_oid = (context.args[0] or "").strip()
    # normalize common copy/paste issues (spaces, backticks, invisible chars)
    oid = re.sub(r"[^0-9A-Za-z_-]", "", raw_oid).upper()
    new_title = " ".join(context.args[1:]).strip()

    if not oid:
        await update.message.reply_text("Please provide a valid order id.")
        return
    if not new_title:
        await update.message.reply_text("Please provide a username/title.")
        return

    async with _db_lock:
        con = _connect()
        cur = con.cursor()

        # 1) exact match (case-insensitive)
        cur.execute("SELECT order_id FROM orders WHERE UPPER(order_id)=? LIMIT 1", (oid,))
        row = cur.fetchone()

        # 2) prefix match (case-insensitive)
        if not row:
            cur.execute(
                "SELECT order_id FROM orders WHERE UPPER(order_id) LIKE ? || '%' "
                "ORDER BY created_at DESC LIMIT 10",
                (oid,)
            )
            matches = [r[0] for r in cur.fetchall()]
            if len(matches) == 1:
                row = (matches[0],)
            elif len(matches) > 1:
                con.close()
                await update.message.reply_text(
                    "Multiple orders match that id/prefix. Please use full Order ID:\n"
                    + "\n".join(matches)
                )
                return

        if not row:
            con.close()
            await update.message.reply_text(
                "Order not found.\n\n"
                "Tip: run /collection today or /pending to copy the exact Order ID.\n"
                f"DB in use: {DB_FILE}"
            )
            return

        real_oid = row[0]
        cur.execute(
            "UPDATE orders SET customer_chat_title=? WHERE order_id=?",
            (new_title, real_oid)
        )
        con.commit()
        con.close()

    await update.message.reply_text(
        f"✅ Customer username updated for <code>{html_escape(real_oid)}</code>\n"
        f"➡️ Customer: {html_escape(new_title)}",
        parse_mode=ParseMode.HTML
    )

async def dbfile_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show current DB file path (admin-only)."""
    if not is_admin(update.effective_user.id):
        return
    if not update.message:
        return
    await update.message.reply_text(
        f"📁 Current DB file path:\n<code>{html_escape(DB_FILE)}</code>",
        parse_mode=ParseMode.HTML
    )


async def collection_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    title_date, title_day, start_ts, end_ts = parse_collection_args(context.args)
    total = await total_collected_filtered(start_ts, end_ts)
    rows = await list_collected_filtered(start_ts, end_ts, limit=30)

    msg_lines = [
        f"<b>{HEADING}</b>\n",
        f"📅 <b>Date:</b> {title_date}",
        f"🗓 <b>Day :</b> {title_day}\n",
        f"💰 <b>Total Collection (PAID + DELIVERED):</b> ₹{total}\n",
        "📒 <b>Latest Collected Orders</b>"
    ]

    if not rows:
        msg_lines.append("No collected orders.")
    else:
        for oid, op_uname, op_uid, cust_title, cust_id, amt, reason, status, paid_at, delivered_at, created_at in rows:
            when_ts = paid_at or delivered_at or created_at
            msg_lines.append(
                f"• <code>{oid}</code> | ₹{int(amt)} | {status} | {reason[:24]} | "
                f"{(cust_title or str(cust_id) if cust_id is not None else '-')} | {only_time(when_ts)}"
            )

    await update.message.reply_text("\n".join(msg_lines), parse_mode=ParseMode.HTML)

async def exportxlsx_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    title_date, title_day, start_ts, end_ts = parse_collection_args(context.args)
    rows = await list_collected_filtered(start_ts, end_ts, limit=10_000_000)
    total = sum(int(r[5]) for r in rows)
    if not rows:
        await update.message.reply_text("No PAID/DELIVERED orders to export.")
        return
    xlsx = export_xlsx_bytes(rows, title_date, title_day, total)
    await update.message.reply_document(document=xlsx, caption=f"✅ Excel Export\nTotal: ₹{total}")

async def exportpdf_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    title_date, title_day, start_ts, end_ts = parse_collection_args(context.args)
    rows = await list_collected_filtered(start_ts, end_ts, limit=10_000_000)
    total = sum(int(r[5]) for r in rows)
    if not rows:
        await update.message.reply_text("No PAID/DELIVERED orders to export.")
        return
    pdf = export_pdf_bytes(rows, title_date, title_day, total)
    await update.message.reply_document(document=pdf, caption=f"✅ PDF Export\nTotal: ₹{total}")


async def exportcsv_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    title_date, title_day, start_ts, end_ts = parse_collection_args(context.args)
    rows = await list_collected_filtered(start_ts, end_ts, limit=10_000_000)
    total = sum(int(r[5]) for r in rows)
    if not rows:
        await update.message.reply_text("No PAID/DELIVERED orders to export.")
        return
    csvf = export_csv_bytes(rows, title_date, title_day, total)
    await update.message.reply_document(document=csvf, caption=f"✅ CSV Export\nTotal: ₹{total}")

def _period_range(kind: str):
    kind = (kind or "").lower()
    if kind in ("today", "day", "daily", "d"): kind = "today"
    if kind in ("week", "weekly", "w"): kind = "week"
    if kind in ("month", "monthly", "m"): kind = "month"
    if kind not in ("today", "week", "month"): kind = "today"
    if kind == "today":
        d1 = d2 = today_date()
    elif kind == "week":
        d2 = today_date(); d1 = d2 - timedelta(days=6)
    else:
        d2 = today_date(); d1 = d2.replace(day=1)
    s, e = date_range_to_ts(d1, d2)
    title = f"{d1.strftime('%d-%m-%Y')} to {d2.strftime('%d-%m-%Y')}" if d1!=d2 else d1.strftime("%d-%m-%Y")
    return title, s, e

async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    kind = context.args[0] if context.args else "today"
    title, start_ts, end_ts = _period_range(kind)
    async with _db_lock:
        con = _connect(); cur = con.cursor()
        # counts by status (created_at within range)
        cur.execute("""
            SELECT status, COUNT(*)
            FROM orders
            WHERE created_at BETWEEN ? AND ?
            GROUP BY status
        """, (start_ts, end_ts))
        counts = {row[0]: int(row[1]) for row in cur.fetchall()}
        con.close()
    total = await total_collected_filtered(start_ts, end_ts)
    # Top reasons among collected (paid+delivered)
    collected_rows = await list_collected_filtered(start_ts, end_ts, limit=10_000_000)
    reason_sum = {}
    reason_cnt = {}
    for r in collected_rows:
        reason = (r[6] or "-").strip()
        reason_cnt[reason] = reason_cnt.get(reason, 0) + 1
        reason_sum[reason] = reason_sum.get(reason, 0) + int(r[5])
    top = sorted(reason_cnt.keys(), key=lambda k: (reason_cnt[k], reason_sum.get(k,0)), reverse=True)[:5]
    lines = [
        f"<b>{HEADING}</b>",
        f"📊 <b>Stats:</b> {title}",
        f"💰 <b>Total Collected (PAID+DELIVERED):</b> ₹{total}",
        "",
        "📦 <b>Status Counts (created in range)</b>",
        f"• Pending: {counts.get('PENDING',0)}",
        f"• Paid: {counts.get('PAID',0)}",
        f"• Delivered: {counts.get('DELIVERED',0)}",
        f"• Canceled: {counts.get('CANCELED',0) + counts.get('CANCELLED',0)}"
    ]
    if top:
        lines.append("\n🏷 <b>Top Reasons (by count)</b>")
        for k in top:
            lines.append(f"• {k[:35]} — {reason_cnt[k]} orders — ₹{reason_sum.get(k,0)}")
    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML)

async def setstatus_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) < 2:
        await update.message.reply_text("Usage: /setstatus <orderid> pending|paid|delivered|cancelled [note...]")
        return
    oid = context.args[0].strip().upper()
    st = context.args[1].strip().upper()
    note = " ".join(context.args[2:]).strip() if len(context.args) > 2 else ""
    mapping = {"PENDING":"PENDING","PAID":"PAID","DELIVERED":"DELIVERED","CANCEL":"CANCELED","CANCELED":"CANCELED","CANCELLED":"CANCELED"}
    if st not in mapping:
        await update.message.reply_text("Status must be: pending, paid, delivered, cancelled")
        return
    ok = await force_set_status(oid, mapping[st], notes=note)
    if not ok:
        await update.message.reply_text("Order not found.")
        return
    row = await get_order(oid)
    await update.message.reply_text("✅ Status updated\n\n" + order_card(row), parse_mode=ParseMode.HTML)
    await log_admin(context.application, f"🛠 <b>SETSTATUS</b> <code>{oid}</code> → <b>{mapping[st]}</b>")

async def note_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) < 2:
        await update.message.reply_text("Usage: /note <orderid> <text>")
        return
    oid = context.args[0].strip().upper()
    note = " ".join(context.args[1:]).strip()
    ok = await append_note(oid, note)
    if not ok:
        await update.message.reply_text("Order not found or empty note.")
        return
    row = await get_order(oid)
    await update.message.reply_text("📝 Note added\n\n" + order_card(row), parse_mode=ParseMode.HTML)

async def cmd_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Plain-text output (no HTML) so placeholders like <orderid> don't crash Telegram parsing
    cmds = [
        "Commands",
        "",
        "Login",
        "/start — login/setup userbot",
        "/cancel — cancel login",
        "",
        "Orders",
        "/pending [limit]",
        "/paid <orderid>",
        "/delivered <orderid>",
        "/cancel <orderid> [note]",
        "/setstatus <orderid> pending|paid|delivered|cancelled [note]",
        "/order <orderid>",
        "/find @username | <orderid> | <reason text>",
        "/setcustomer <orderid> @username_or_name",
        "/note <orderid> <text>",
        "",
        "Collection",
        "/collection [today|yesterday|week|month|total|DD-MM-YYYY DD-MM-YYYY]",
        "/exportxlsx [same as /collection]",
        "/exportpdf [same as /collection]",
        "/exportcsv [same as /collection]",
        "/stats today|week|month",
        "",
        "Keywords",
        "/addkeyword <word>",
        "/setreply <word> <reply>",
        "/delkeyword <word>",
        "",
        "/cmd — show this list",
    ]
    await update.message.reply_text("\n".join(cmds))


# =========================
# DAILY BACKUP
# =========================
def ensure_backup_folder():
    if not os.path.isdir(BACKUP_FOLDER):
        os.makedirs(BACKUP_FOLDER, exist_ok=True)

async def backup_job(context):
    ensure_backup_folder()
    today = datetime.now(TZ).strftime("%Y-%m-%d")
    dst = os.path.join(BACKUP_FOLDER, f"orders_backup_{today}.db")
    try:
        shutil.copy2(DB_FILE, dst)
        await log_admin(context.application, f"💾 Backup saved: <code>{dst}</code>")
    except Exception as e:
        await log_admin(context.application, f"⚠️ Backup failed: {e}")

async def manual_daily_backup_loop(app: Application):
    class Ctx:
        def __init__(self, application):
            self.application = application

    while True:
        now = datetime.now(TZ)
        next_run = now.replace(hour=BACKUP_TIME_HOUR, minute=0, second=0, microsecond=0)
        if next_run <= now:
            next_run = next_run + timedelta(days=1)

        await asyncio.sleep((next_run - now).total_seconds())
        try:
            await backup_job(Ctx(app))
        except Exception as e:
            print("Manual backup failed:", e)

# =========================
# MAIN
# =========================
async def main():
    if not BOT_TOKEN or BOT_TOKEN == "PASTE_BOT_TOKEN_HERE":
        raise SystemExit("Set BOT_TOKEN env var or paste it in the script.")

    await db_init()
    ensure_backup_folder()

    app = Application.builder().token(BOT_TOKEN).build()

    login_conv = ConversationHandler(
        entry_points=[CommandHandler("start", start_cmd)],
        states={
            S_API_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, login_api_id)],
            S_API_HASH: [MessageHandler(filters.TEXT & ~filters.COMMAND, login_api_hash)],
            S_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, login_phone)],
            S_CODE: [MessageHandler(filters.TEXT & ~filters.COMMAND, login_code)],
            S_2FA: [MessageHandler(filters.TEXT & ~filters.COMMAND, login_2fa)],
        },
        fallbacks=[CommandHandler("cancel", cancel_login)],
        allow_reentry=True
    )
    app.add_handler(login_conv)

    # Keyword management
    app.add_handler(CommandHandler("addkeyword", addkeyword_cmd))
    app.add_handler(CommandHandler("setreply", setreply_cmd))
    app.add_handler(CommandHandler("delkeyword", delkeyword_cmd))

    # Orders
    app.add_handler(CommandHandler("pending", pending_cmd))
    app.add_handler(CommandHandler("paid", paid_cmd))
    app.add_handler(CommandHandler("delivered", delivered_cmd))
    app.add_handler(CommandHandler("cancel", cancel_cmd))
    app.add_handler(CommandHandler("order", order_cmd))
    app.add_handler(CommandHandler("find", find_cmd))
    app.add_handler(CommandHandler("setcustomer", setcustomer_cmd))
    app.add_handler(CommandHandler("dbfile", dbfile_cmd))

    # Collection + exports
    app.add_handler(CommandHandler("collection", collection_cmd))
    app.add_handler(CommandHandler("exportxlsx", exportxlsx_cmd))
    app.add_handler(CommandHandler("exportpdf", exportpdf_cmd))
    app.add_handler(CommandHandler("exportcsv", exportcsv_cmd))
    app.add_handler(CommandHandler("stats", stats_cmd))
    app.add_handler(CommandHandler("setstatus", setstatus_cmd))
    app.add_handler(CommandHandler("note", note_cmd))
    app.add_handler(CommandHandler("cmd", cmd_cmd))

    # Daily backup at 2 AM (JobQueue if available, else manual loop)
    if app.job_queue is not None:
        backup_time = datetime.now(TZ).replace(hour=BACKUP_TIME_HOUR, minute=0, second=0, microsecond=0).timetz()
        app.job_queue.run_daily(
            backup_job,
            time=backup_time,
            days=(0, 1, 2, 3, 4, 5, 6),
            name="daily_db_backup"
        )
    else:
        print("⚠️ JobQueue not available. Using manual daily backup loop.")
        asyncio.create_task(manual_daily_backup_loop(app))

    # Start bot polling
    await app.initialize()
    await app.start()
    if getattr(app, 'updater', None) is None or app.updater is None:
        raise SystemExit("Your python-telegram-bot install does not include an Updater. Install/upgrade: pip install -U python-telegram-bot==20.*")
    await app.bot.delete_webhook(drop_pending_updates=True)
    await app.updater.start_polling(drop_pending_updates=True)# Start userbot if already logged in
    await start_userbot(app)

    print("✅ Controller bot running. Open your bot and type /start.")
    await asyncio.Event().wait()


if __name__ == "__main__":
    # Auto-restart on network glitches / transient failures (no scary tracebacks)
    while True:
        try:
            asyncio.run(main())
        except (KeyboardInterrupt, SystemExit):
            raise
        except (NetworkError, TimedOut, RetryAfter) as e:
            print(f"⚠️ Network issue (auto-retry): {e}")
            time.sleep(10)
        except Exception as e:
            print(f"❌ Fatal error: {e}")
            time.sleep(10)
